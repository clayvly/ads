const classFun = (className, value, property) => {
    const elements = document.getElementsByClassName(className);
    for (let i = 0; i < elements.length; i++) {
        if (property === 'inner') {
            elements[i].innerHTML = value;
        } else if (property === 'img') {
            elements[i].src = value;
        }
    }
}

function classImg(className, src) {
    return classFun(className, src, 'img');
}

function classInner(className, value) {
    return classFun(className, value, 'inner');
}

function getLast30Days() {
    const currentDate = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(currentDate.getDate() - 27);

    const currentDateString = currentDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
    const thirtyDaysAgoString = thirtyDaysAgo.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });

    return `${thirtyDaysAgoString} - ${currentDateString}`;
}

function getEarlyMonth() {
    const currentDate = new Date();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);

    const currentDateString = currentDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
    const firstDayOfMonthString = firstDayOfMonth.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });

    return `${firstDayOfMonthString} - ${currentDateString}`;
}



async function fetchData(value) {
    try {
        const response = await fetch(value);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const jsonData = await response.json();
        // Now you can use the data from jsonData
        return jsonData;
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

export {
    classImg,
    classInner,
    getLast30Days,
    fetchData,
    getEarlyMonth
};