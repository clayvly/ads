import { classImg, classInner, getLast30Days, fetchData } from './function.js';
const data = await fetchData('../data.json');

// Set the billing details
classInner("fbName", `${data.profile.name} (${data.profile.id})`);
classInner("fbBalance", data.profile.balance);
classImg("fbImg", data.profile.images);
classInner("fbDate", getLast30Days());

// Loop over data.billings and append each billing to the table
const table = document.getElementsByClassName("fbTableTransaction")[0];
let tableData = "";
data.billings.forEach(billing => {
    tableData += `<tr class="xb9moi8 xfth1om x21b0me xmls85d xso031l x9f619 x1sy0etr" role="row" style="display: grid; grid-template-columns: minmax(0px, 1fr) minmax(0px, 1fr) minmax(0px, 1fr) minmax(0px, 1fr) minmax(0px, 1fr) minmax(0px, 1fr) minmax(0px, 0.5fr); width: min-content; min-width: 100%;">
  <td aria-colindex="1" class="x1n2onr6 x1yc453h x78zum5 x1nhvcw1 xb9moi8 xfth1om x21b0me xmls85d x1gzqxud x108nfp6 x8t9es0 x1fvot60 xo1l8bm xxio538 xyamay9 x1pi30zi x1l90r2v x1swvt13 x6s0dn4" role="gridcell" tabindex="0" style="grid-area: 1 / 1 / auto / 2;">
    <div class="x1iyjqo2 xh8yej3 xmz0i5r">
      <div>
        <a class="xt0psk2 x1hl2dhg xt0b8zv x8t9es0 x1fvot60 xxio538 xjnfcd9 xq9mrsl x1yc453h x1h4wwuj x1fcty0u" target="_blank" href="#">${billing.id}</a>
      </div>
    </div>
  </td>
  <td aria-colindex="2" class="x1n2onr6 x1yc453h x78zum5 x1nhvcw1 xb9moi8 xfth1om x21b0me xmls85d x1gzqxud x108nfp6 x8t9es0 x1fvot60 xo1l8bm xxio538 xyamay9 x1pi30zi x1l90r2v x1swvt13 x6s0dn4" role="gridcell" tabindex="0" style="grid-area: 1 / 2 / auto / 3;">
    <div class="x1iyjqo2 xh8yej3 xmz0i5r">
      <span class="x8t9es0 x1fvot60 xo1l8bm xxio538 x108nfp6 xq9mrsl x1h4wwuj xeuugli">${billing.date}</span>
    </div>
  </td>
  <td aria-colindex="3" class="x1n2onr6 x1yc453h x78zum5 x1nhvcw1 xb9moi8 xfth1om x21b0me xmls85d x1gzqxud x108nfp6 x8t9es0 x1fvot60 xo1l8bm xxio538 xyamay9 x1pi30zi x1l90r2v x1swvt13 x6s0dn4" role="gridcell" tabindex="0" style="grid-area: 1 / 3 / auto / 4;">
    <div class="x1iyjqo2 xh8yej3 xmz0i5r">
      <span class="x8t9es0 x1fvot60 xo1l8bm xxio538 x108nfp6 xq9mrsl x1h4wwuj xeuugli">Rp${billing.totals}</span>
    </div>
  </td>
  <td aria-colindex="4" class="x1n2onr6 x1yc453h x78zum5 x1nhvcw1 xb9moi8 xfth1om x21b0me xmls85d x1gzqxud x108nfp6 x8t9es0 x1fvot60 xo1l8bm xxio538 xyamay9 x1pi30zi x1l90r2v x1swvt13 x6s0dn4" role="gridcell" tabindex="0" style="grid-area: 1 / 4 / auto / 5;">
    <div class="x1iyjqo2 xh8yej3 xmz0i5r">
      <div class="x6s0dn4 x78zum5 x1nhvcw1">
        <div class="xl010v5 x1gslohp">
          ${billing.type}
        </div>
        <div class="xeuugli">
          <div class="x8t9es0 x1fvot60 xo1l8bm xxio538 x108nfp6 xq9mrsl x1h4wwuj xeuugli">${billing.method}</div>
        </div>
      </div>
    </div>
  </td>
  <td aria-colindex="5" class="x1n2onr6 x1yc453h x78zum5 x1nhvcw1 xb9moi8 xfth1om x21b0me xmls85d x1gzqxud x108nfp6 x8t9es0 x1fvot60 xo1l8bm xxio538 xyamay9 x1pi30zi x1l90r2v x1swvt13 x6s0dn4" role="gridcell" tabindex="0" style="grid-area: 1 / 5 / auto / 6;">
    <div class="x1iyjqo2 xh8yej3 xmz0i5r">
      <div class="x78zum5">
        <span class="x3nfvp2 xmix8c7 x1n2onr6">
          <span class="x6s0dn4 x9f619 x78zum5 xmix8c7 xl56j7k x16xo4sp x1t137rt x1j85h84 xsyo7zv x16hj40l x4p5aij x1n2onr6 xzolkzo x12go9s9 x1rnf11y xprq8jg x8t9es0 xw23nyj x63nzvj x1fp01tm xuxw1ft x2b8uid x117nqv4 x1fwvgxd">
            <div class="x8t9es0 xw23nyj x63nzvj x1heor9g xuxw1ft x6ikm8r x10wlt62 xlyipyv x1h4wwuj x1pd3egz xeuugli">${billing.status}</div>
          </span>
          <div aria-atomic="true" aria-live="polite" role="status" class="x1qvwoe0 xjm9jq1 x1y332i5 xcwd3tp x1jyxor1 x39eecv x6ikm8r x10wlt62 x10l6tqk xuxw1ft x1i1rx1s" data-sscoverage-ignore="true">Lunas</div>
        </span>
      </div>
    </div>
  </td>
  <td aria-colindex="6" class="x1n2onr6 x1yc453h x78zum5 x1nhvcw1 xb9moi8 xfth1om x21b0me xmls85d x1gzqxud x108nfp6 x8t9es0 x1fvot60 xo1l8bm xxio538 xyamay9 x1pi30zi x1l90r2v x1swvt13 x6s0dn4" role="gridcell" tabindex="0" style="grid-area: 1 / 6 / auto / 7;">
    <div class="x1iyjqo2 xh8yej3 xmz0i5r">
      <span class="x8t9es0 x1fvot60 xo1l8bm xxio538 x108nfp6 xq9mrsl x1h4wwuj xeuugli">${billing.id_tax}</span>
    </div>
  </td>
  <td aria-colindex="7" class="x1n2onr6 x1yc453h x78zum5 x1nhvcw1 xb9moi8 xfth1om x21b0me xmls85d x1gzqxud x108nfp6 x8t9es0 x1fvot60 xo1l8bm xxio538 xyamay9 x1pi30zi x1l90r2v x1swvt13 x6s0dn4" role="gridcell" tabindex="0" style="grid-area: 1 / 7 / auto / 8;">
    <div class="x1iyjqo2 xh8yej3 xmz0i5r">
      <div class="xeq5yr9" title="Unduh">
        <div class="x3nfvp2 x193iq5w xxymvpz" role="none">
          <a aria-busy="false" class="x1i10hfl xjqpnuy xa49m3k xqeqjp1 x2hbi6w x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli x16tdsg8 xggy1nq x1ja2u2z x1t137rt x6s0dn4 x1ejq31n xd10rxx x1sy0etr x17r0tee x3nfvp2 xdl72j9 x1q0g3np x2lah0s x193iq5w x1n2onr6 x1hl2dhg x87ps6o xxymvpz xlh3980 xvmahel x1lku1pv xhk9q7s x1otrzb0 x1i1ezom x1o6z2jb xo1l8bm x108nfp6 xas4zb2 x1y1aw1k xwib8y2 x1ye3gou xn6708d" href="/ads/manage/billing_transaction/?act=1698344666987941&amp;pdf=true&amp;print=false&amp;source=billing_summary&amp;tx_type=3&amp;txid=7676696239114379-7752420854875258" role="link" tabindex="0" target="_blank">
            <span class="x8t9es0 x1fvot60 xxio538 x1heor9g xq9mrsl x1h4wwuj x1pd3egz xeuugli xh8yej3">
              <div class="x78zum5">
                <div class="x1qvwoe0 xjm9jq1 x1y332i5 xcwd3tp x1jyxor1 x39eecv x6ikm8r x10wlt62 x10l6tqk xuxw1ft x1i1rx1s" data-sscoverage-ignore="true">Unduh PDF</div>
                <div class="x6s0dn4 x78zum5 x1q0g3np xozqiw3 x2lwn1j xeuugli x1iyjqo2 x19lwn94 x1hc1fzr x13dflua x6o7n8i xxziih7 x12w9bfk xl56j7k xh8yej3">
                  <div class="x3nfvp2 x2lah0s x1c4vz4f">
                    <i alt="" data-visualcompletion="css-img" class="img sp_hK5E2xlV7kB sx_cb1f6d"></i>
                  </div>&ZeroWidthSpace;
                </div>
              </div>
            </span>
          </a>
        </div>
      </div>
    </div>
  </td>
</tr>`;
});
table.innerHTML = tableData;