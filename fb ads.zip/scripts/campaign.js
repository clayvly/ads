import { classImg, classInner, getEarlyMonth, fetchData } from './function.js';
const data = await fetchData('../data.json');

// Set the billing details
classInner("fbName", `${data.profile.name} (${data.profile.id})`);
classImg("fbImg", data.profile.images);
classInner("fbDate", getEarlyMonth());

const height = 46;
const tableLength = data.ads.length;

let resultHeight = 80;
resultHeight += height * tableLength;
const styleResult = `width: 1059px; height: 64px; z-index: 1; transform: translate(0px, ${resultHeight}px);`

let defaultTableHeight = 146;
defaultTableHeight += (height * tableLength);

// Set height for the tables
const defaultTables = document.getElementsByClassName("fbDefaultTable");
for (let i = 0; i < defaultTables.length; i++) {
    defaultTables[i].style.height = `${defaultTableHeight}px`;
}

const resultTables = document.getElementsByClassName("fbResultTable");
for (let i = 0; i < resultTables.length; i++) {
    resultTables[i].setAttribute('style', styleResult);
}

// Set the tables Ads
const table = document.getElementsByClassName("fbTableData")[0];
let tableData = "";
let dataHeight = 0;
let totalAmountSpended = 0;

data.ads.forEach(ad => {
    let enabledInner = ``;
    let statusInner = ``;
    let amountSpended = ad.result.replace(".", "") * ad.costPerResult.replace(".", "");
    totalAmountSpended += parseInt(amountSpended);
    amountSpended = amountSpended.toString().split('').reverse().join('').replace(/(\d{3}(?!$))/g, '$1.').split('').reverse().join('');

    if (ad.enabled) {
        enabledInner = `<input aria-checked="true" aria-label="Aktif/Nonaktif" role="switch" aria-describedby="js_1hp" aria-labelledby="js_1m5" class="xjyslct x1ypdohk x5yr21d x17qophe xdj266r x11i5rnm xat24cr x1mh8g0r x1w3u9th x1t137rt x10l6tqk x13vifvy xh8yej3 x1vjfegm" id="js_1ho" type="checkbox" value="true">`;
    } else {
        enabledInner = `<input aria-checked="false" aria-label="On/Off" role="switch" aria-describedby="js_9g" aria-labelledby="js_fx" class="xjyslct x1ypdohk x5yr21d x17qophe xdj266r x11i5rnm xat24cr x1mh8g0r x1w3u9th x1t137rt x10l6tqk x13vifvy xh8yej3 x1vjfegm" id="js_9f" type="checkbox" value="false" checked="" data-auto-logging-id="f1610cdfb5f0f2">`;
    }

    if (ad.status) { 
        statusInner = `<span> <div class="ellipsis"><span><span> <div class="clearfix _ikh"> <div class="_4bl7"> <div class="x1yc453h x1kky2od x1y5rjcf"><i alt="" data-visualcompletion="css-img" class="img" style="background-image: url(&quot;https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/0kR-0VZ-QnN.png?_nc_eui2=AeFyMjVxY10In9bRdNkUwIcuM42q6x7zT14zjarrHvNPXrs1o8l-6AY8z_Zu4ur6bJu7rgBc9dnApPxxUxkFrXDU&quot;); background-position: -13px -3361px; background-size: auto; width: 8px; height: 8px; background-repeat: no-repeat; display: inline-block;"></i></div> </div> <div class="_4bl9"><span class="x8t9es0 x1fvot60 xo1l8bm xxio538 x108nfp6 xq9mrsl x1h4wwuj xeuugli">Aktif</span></div> </div> </span> <div data-visualcompletion="ignore" class=""></div> </span></div> </span>`;
    } else {
        statusInner = `<span><div class="ellipsis"><span><span><div class="clearfix _ikh"><div class="_4bl7"><div class="x1yc453h x1kky2od x1y5rjcf"><i alt="" data-visualcompletion="css-img" class="img" style="background-image: url(&quot;https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/0kR-0VZ-QnN.png?_nc_eui2=AeFyMjVxY10In9bRdNkUwIcuM42q6x7zT14zjarrHvNPXrs1o8l-6AY8z_Zu4ur6bJu7rgBc9dnApPxxUxkFrXDU&quot;); background-position: -13px -3370px; background-size: auto; width: 8px; height: 8px; background-repeat: no-repeat; display: inline-block;"></i></div></div><div class="_4bl9"><span class="x8t9es0 x1fvot60 xo1l8bm xxio538 x108nfp6 xq9mrsl x1h4wwuj xeuugli">Kampanye Nonaktif</span></div></div></span><div data-visualcompletion="ignore" class=""></div></span></div></span>`;
    }

    tableData += `<div class="_1gda _2djg" style="width: 1059px; height: 46px; z-index: 0; transform: translate(0px, ${dataHeight}px);">
        <div class="_1gd4 _4li _52no  _5a1o _5a1n _3c7k" role="presentation" style="width: 1059px; height: 46px;">
            <div class="_1gd5">
                <div class="_3pzk" style="height: 46px; left: 0px;">
                    <div class="_3pzj" style="height: 46px; position: absolute; width: 495px; will-change: transform; z-index: 2; transform: translate(0px, 0px);">
                        <div class="_4lg0 _4lg6 _4h2q _4h2m" style="height: 46px; width: 49px; left: 0px;">
                            <div class="_1b33 _1xah">
                                <div class="x1rg5ohu x5yr21d">
                                    <div class="x6s0dn4 x78zum5 xl56j7k x2lwn1j xeuugli x5yr21d"><span id="row-checkbox-0">
                                            <div class="x1rg5ohu x1n2onr6 x3oybdh">
                                                <div class="x1n2onr6 x14atkfc">
                                                    <div class="x6s0dn4 x78zum5 x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x178xt8z xm81vs4 xso031l xy80clv xb9moi8 xfth1om x21b0me xmls85d xhk9q7s x1otrzb0 x1i1ezom x1o6z2jb x1gzqxud x108nfp6 x9f619 xexx8yu x4uap5 x18d9i69 xkhd6sd xl56j7k xxk0z11 xvy4d1p">
                                                        <div class=""></div><input aria-checked="false" aria-disabled="false" aria-label="" aria-describedby="js_1hl" aria-labelledby="js_1hm" class="xjyslct x1ypdohk x5yr21d x17qophe xdj266r x11i5rnm xat24cr x1mh8g0r x1w3u9th x1t137rt x10l6tqk x13vifvy xh8yej3 x1vjfegm" id="js_1hk" type="checkbox">
                                                        <div class="x13dflua xnnyp6c x12w9bfk x78zum5 xg01cxk x1f85oc2 x6o7n8i">
                                                            <div class="x3nfvp2 x120ccyz x923533" role="presentation"><svg height="16" viewBox="0 0 16 16" width="16">
                                                                    <path d="M13.305 3.28L5.993 10.6l-3.31-3.306a1 1 0 00-1.415 1.414l4.013 4.012a.997.997 0 001.414 0l8.024-8.024a1 1 0 00-1.414-1.416z"></path>
                                                                </svg></div>
                                                        </div>
                                                    </div>
                                                    <div class="xb9moi8 xfth1om x21b0me xmls85d xhk9q7s x1otrzb0 x1i1ezom x1o6z2jb x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x178xt8z xm81vs4 xso031l xy80clv x13dflua x6o7n8i xxziih7 x12w9bfk xg01cxk x47corl x10l6tqk x17qophe xds687c x13vifvy x1ey2m1c x6ikm8r x10wlt62 xnl74ce xmb4j5p xdx8kah xwmxa91 xmn8db3 x8lbu6m x2te4dl x1bs8fl3 xhhp2wi x14q35kh x1wa3ocq x1n7iyjn x1t0di37 x1tt7eqi xe25xm5 xsp6npd x1s928wv x1w3onc2 x1j6awrg x9obomg x1ryaxvv x1hvfe8t x1te75w5"></div>
                                                </div>
                                            </div>
                                        </span></div>
                                </div>
                            </div>
                        </div>
                        <div class="_4lg0 _4h2m" style="height: 46px; width: 86px; left: 49px;">
                            <div class="_1b33 _a524">
                                <div class="x6s0dn4 x78zum5 xl56j7k x2lwn1j xeuugli x5yr21d">
                                    <div data-visualcompletion="ignore" class="">
                                        <div>
                                            <div class="x6s0dn4 x78zum5 x1q0g3np xozqiw3 x2lwn1j xeuugli x19lwn94 x1c4vz4f">
                                                <div class="x1rg5ohu x1n2onr6 x3oybdh">${enabledInner}
                                                    <div class="x1n2onr6 xh8yej3">
                                                        <div class="x6s0dn4 x78zum5 x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x178xt8z xm81vs4 xso031l xy80clv xb9moi8 xfth1om x21b0me xmls85d xzolkzo x12go9s9 x1rnf11y xprq8jg xo1l8bm x108nfp6 xlvp1be x13dflua xxziih7 x12w9bfk x14qfxbe xexx8yu x4uap5 x18d9i69 xkhd6sd x15406qy">
                                                            <div class=""></div>
                                                            <div class="xw4jnvo x1qx5ct2 x1h45990 xzolkzo x12go9s9 x1rnf11y xprq8jg x13dflua x6o7n8i xxziih7 x12w9bfk x923533 x1psfjxj"></div>
                                                        </div>
                                                        <div class="xb9moi8 xfth1om x21b0me xmls85d xzolkzo x12go9s9 x1rnf11y xprq8jg x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x178xt8z xm81vs4 xso031l xy80clv x13dflua x6o7n8i xxziih7 x12w9bfk xg01cxk x47corl x10l6tqk x17qophe xds687c x13vifvy x1ey2m1c x6ikm8r x10wlt62 xnl74ce xmb4j5p xdx8kah xwmxa91 xmn8db3 x8lbu6m x2te4dl x1bs8fl3 xhhp2wi x14q35kh x1wa3ocq x1n7iyjn x1t0di37 x1tt7eqi xe25xm5 xsp6npd x1s928wv x1w3onc2 x1j6awrg x9obomg x1ryaxvv x1hvfe8t x1te75w5"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="_4lg0 _4h2m" style="height: 46px; width: 360px; left: 135px;">
                            <div class="_vz_ _1b33" id="js_1hs">
                                <div class="_vzz _vzz _5f0d" height="46" src="https://scontent.fcgk6-3.fna.fbcdn.net/v/t15.5256-10/438218192_467530425873382_8415068473511581786_n.jpg?_nc_cat=111&amp;ccb=1-7&amp;_nc_eui2=AeESLBft-MJCS9UbdRp-bXY_JPi1zvBbFtAk-LXO8FsW0NdBzY6TfKNohCc5rFcDIA52VqQvI1C1JKaiGq_qXklV&amp;_nc_ohc=zsmDu7y08VEQ7kNvgGau_n6&amp;_nc_ht=scontent.fcgk6-3.fna&amp;gid=Al-qB2R0CNZuT4j2HnD8ouj&amp;stp=c0.5000x0.5000f_dst-emg0_p46x46_q75&amp;ur=7965db&amp;_nc_sid=58080a&amp;oh=00_AYDsM8fK-Whf08i1yA1EHVZIaarNE4A0txz771D7HfaEHQ&amp;oe=668D7213" width="46" style="width: 46px; height: 46px;"><img alt="" class="_5i4g img" src="${ad.adsImg}" style="width: 46px; height: 46px; left: 0px; top: 0px;"></div>
                                <div class="_2czl">
                                    <div class="_62h_">
                                        <div class="_62i0">
                                            <div class="ellipsis _13is" data-hover="tooltip" data-tooltip-content="03/07/2024" data-tooltip-display="overflow" data-tooltip-position="above" data-tooltip-text-direction="auto">
                                                <div data-visualcompletion="ignore" class="xt0psk2"></div><span class="_3dfi _3dfj">${ad.adsTitle}</span>
                                            </div>
                                            <div data-visualcompletion="ignore" class=""><a aria-label="Edit" class="xt0psk2 x1hl2dhg xt0b8zv x8t9es0 x1fvot60 xxio538 xjnfcd9 xq9mrsl x1yc453h x1h4wwuj x1fcty0u" href="#">
                                                    <div class="_5_6n"><span class="_5_6o"></span></div>
                                                </a></div>
                                        </div>
                                        <div data-visualcompletion="ignore" class=""></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_3pzk" style="height: 46px; left: 495px;">
                    <div class="_3pzj" style="height: 46px; position: absolute; width: 2273px; will-change: transform; z-index: 0; transform: translate(0px, 0px);">
                        <div class="_4lg0 _4lg5 _4h2p _4h2m" style="height: 46px; width: 146px; left: 0px;"><span><span>
                                    <div class=" _1b33 _e9h">
                                        <div class="_e9n">
                                            <div class="">
                                                <div class="ellipsis _1ha3" geotextcolor="value" data-hover="tooltip" data-tooltip-display="overflow" data-tooltip-text-direction="auto"><span>${ad.result}</span></div>
                                                <div class="ellipsis _1ha4" data-hover="tooltip" data-tooltip-display="overflow" data-tooltip-text-direction="auto"><span>Kunjungan Profil Instagram</span></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-visualcompletion="ignore" class=""></div>
                                </span></span></div>
                        <div class="_4lg0 _4lg5 _4h2p _4h2m" style="height: 46px; width: 146px; left: 146px;">
                            <div class=" _1b33 _e9h">
                                <div class="_e9n">
                                    <div class="">
                                        <div class="ellipsis _1ha3" geotextcolor="value" data-hover="tooltip" data-tooltip-display="overflow" data-tooltip-text-direction="auto"><span><span class="_3dfi _3dfj">Rp ${ad.costPerResult}</span></span></div>
                                        <div class="ellipsis _1ha4" data-hover="tooltip" data-tooltip-display="overflow" data-tooltip-text-direction="auto">Per Kunjungan Profil Instagram</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="_4lg0 _4lg5 _4h2p _4h2m" style="height: 46px; width: 146px; left: 292px;">
                            <div class=" _1b33 _e9h">
                                <div class="_e9n">
                                    <div class="">
                                        <div class="ellipsis _1ha3" geotextcolor="value" data-hover="tooltip" data-tooltip-display="overflow" data-tooltip-text-direction="auto"><span class="_3dfi _3dfj">Rp ${amountSpended}</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="_4lg0 _4h2m" style="height: 46px; width: 200px; left: 438px;">
                            <div class="_1b33">${statusInner}
                                            <div data-visualcompletion="ignore" class=""></div>
                                        </span></div>
                                </span></div>
                        </div>
                    </div>
                </div>
                <div class="_1gd6 _1gd8" style="left: 495px; height: 46px;"></div>
            </div>
        </div>
    </div>`;
    dataHeight += 46;
})
table.innerHTML = tableData;
totalAmountSpended = totalAmountSpended.toString().split('').reverse().join('').replace(/(\d{3}(?!$))/g, '$1.').split('').reverse().join('');
document.getElementsByClassName("fbTotalAmountSpended")[0].innerHTML = `Rp ${totalAmountSpended}`