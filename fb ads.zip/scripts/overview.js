import { classImg, classInner, getLast30Days, fetchData } from './function.js';
const data = await fetchData('../data.json');

// Set the billing details
classInner("fbOnlyName", `${data.profile.name}`);
classInner("fbName", `${data.profile.name} (${data.profile.id})`);
classImg("fbImg", data.profile.images);

classInner("fbSpendingLimit", data.overview.spendingLimit);
classInner("fbSpended", data.overview.spended);
classInner("fbLastWeekSpend", data.overview.lastWeekSpend);
classInner("fbWeekSpendFormat", data.overview.lastWeekSpendFormat);